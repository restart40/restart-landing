
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/admin', express.static(path.join(__dirname, '../admin')));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Auth Middleware
function verifyToken(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).send('Token requerido');

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).send('Token inválido');
        req.user = decoded;
        next();
    });
}

// Login route
app.post('/api/login', (req, res) => {
    const { password } = req.body;
    if (password === process.env.ADMIN_PASSWORD) {
        const token = jwt.sign({ admin: true }, process.env.JWT_SECRET, { expiresIn: '2h' });
        res.json({ token });
    } else {
        res.status(401).send('Contraseña incorrecta');
    }
});

// Content Management (Protected)
app.get('/api/content', verifyToken, (req, res) => {
    const data = fs.readFileSync(path.join(__dirname, '../data/content.json'), 'utf-8');
    res.json(JSON.parse(data));
});

app.post('/api/content', verifyToken, (req, res) => {
    fs.writeFileSync(path.join(__dirname, '../data/content.json'), JSON.stringify(req.body, null, 2));
    res.send('Contenido actualizado');
});

app.listen(PORT, () => {
    console.log(`Servidor activo en http://localhost:${PORT}`);
});


const multer = require('multer');

// Configurar almacenamiento del archivo
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '../public/assets'));
    },
    filename: function (req, file, cb) {
        cb(null, 'video.mp4'); // se sobrescribe siempre con el mismo nombre
    }
});

const upload = multer({
    storage: storage,
    fileFilter: function (req, file, cb) {
        if (file.mimetype !== 'video/mp4') {
            return cb(new Error('Solo se permiten archivos MP4'));
        }
        cb(null, true);
    }
});

app.post('/api/upload', verifyToken, upload.single('video'), (req, res) => {
    res.send('Video subido correctamente');
});
